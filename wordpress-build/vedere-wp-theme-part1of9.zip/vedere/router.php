<?php
/**
 * Vedere static router — maps request paths to the pre-built HTML pages.
 * Pure functions, no WordPress dependencies (unit-testable from CLI).
 */

function vedere_manifest() {
    static $man = null;
    if ($man === null) {
        $man = json_decode(file_get_contents(__DIR__ . '/manifest.json'), true);
    }
    return $man;
}

/**
 * Resolve a request path to a page filename, or null.
 * Accepts canonical paths (/greece, /formula-one/monaco-grand-prix-2027),
 * legacy .html paths (/greece.html), with or without trailing slash.
 */
function vedere_resolve($path) {
    $man = vedere_manifest();
    $p = trim(parse_url($path, PHP_URL_PATH) ?? '', '/');
    $p = rawurldecode($p);
    if ($p === '' || $p === 'index.html') return $man[''] ?? 'index.html';
    if (isset($man[$p])) return $man[$p];
    // legacy flat .html URL → look up by basename
    $base = basename($p);
    if (substr($base, -5) === '.html') {
        foreach ($man as $file) {
            if ($file === $base) return $file;
        }
    }
    // flat slug that only exists as a nested canonical (e.g. /monaco-grand-prix-2027)
    foreach ($man as $canon => $file) {
        if ($file === $base . '.html') return $file;
        if (basename($canon) === $p) return $file;
    }
    return null;
}

/** Serve a theme file with the right content type. Returns true if served. */
function vedere_serve($path) {
    $p = trim(parse_url($path, PHP_URL_PATH) ?? '', '/');

    // static passthroughs
    if ($p === 'sitemap.xml') {
        header('Content-Type: application/xml; charset=UTF-8');
        readfile(__DIR__ . '/sitemap.xml');
        return true;
    }
    if ($p === 'robots.txt' && file_exists(__DIR__ . '/robots.txt')) {
        header('Content-Type: text/plain; charset=UTF-8');
        readfile(__DIR__ . '/robots.txt');
        return true;
    }
    // safety net for any legacy /assets/... URL (og:image shares etc.)
    if (strpos($p, 'assets/') === 0) {
        $file = realpath(__DIR__ . '/' . $p);
        if ($file && strpos($file, realpath(__DIR__ . '/assets')) === 0 && is_file($file)) {
            $types = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','svg'=>'image/svg+xml','mp4'=>'video/mp4','css'=>'text/css','js'=>'application/javascript'];
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
            header('Cache-Control: public, max-age=31536000, immutable');
            readfile($file);
            return true;
        }
        return false;
    }

    $file = vedere_resolve($path);
    if ($file === null) return false;
    $full = __DIR__ . '/pages/' . $file;
    if (!is_file($full)) return false;
    header('Content-Type: text/html; charset=UTF-8');
    status_header_safe(200);
    readfile($full);
    return true;
}

function status_header_safe($code) {
    if (function_exists('status_header')) { status_header($code); }
    else { http_response_code($code); }
}
