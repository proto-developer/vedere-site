<?php
/**
 * Vedere Travel theme — serves the approved static build through WordPress.
 * All pages live in /pages, all imagery in /assets. URLs match the static
 * site's canonical structure (e.g. /greece, /formula-one/monaco-grand-prix-2027).
 */
require_once __DIR__ . '/router.php';

// Serve matching pages before WordPress builds a query.
add_action('parse_request', function ($wp) {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    if (vedere_serve($uri)) { exit; }
}, 0);

// Keep WordPress from redirecting /greece to a WP page that doesn't exist.
add_filter('redirect_canonical', function ($redirect, $requested) {
    return vedere_resolve($requested) ? false : $redirect;
}, 10, 2);

// Point WP's virtual robots.txt at our sitemap if no physical file is used.
add_filter('robots_txt', function ($output) {
    if (strpos($output, 'Sitemap:') === false) {
        $output .= "\nSitemap: https://vederetravel.com/sitemap.xml\n";
    }
    return $output;
}, 20);

// Disable WP's own sitemap so ours at /sitemap.xml is the only one.
add_filter('wp_sitemaps_enabled', '__return_false');
