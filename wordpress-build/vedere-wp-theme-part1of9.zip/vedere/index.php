<?php
// Fallback: if WordPress ever reaches the template layer, serve the homepage
// for the root, or the static build's 404 behaviour for anything unknown.
require_once __DIR__ . '/router.php';
if (!vedere_serve($_SERVER['REQUEST_URI'] ?? '/')) {
    status_header_safe(404);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><meta charset="utf-8"><title>Not found — Vedere Travel</title><body style="font-family:Georgia,serif;background:#FBFAF7;color:#0D1F17;display:grid;place-items:center;min-height:100vh"><div style="text-align:center"><p style="letter-spacing:.3em;color:#B8965A">VEDERE</p><h1 style="font-weight:400">This page has moved on.</h1><p><a href="/" style="color:#B8965A">Return to the beginning</a></p></div>';
}
